package com.web.scraping.rategain;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RategainApplication {

	public static void main(String[] args) {
		SpringApplication.run(RategainApplication.class, args);
	}

}
