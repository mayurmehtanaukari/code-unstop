import { Component, Injectable } from '@angular/core';
import { HttpClient } from  '@angular/common/http';
import * as XLSX from 'xlsx'; 

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
@Injectable({
  providedIn:  'root'
  })
  
export class AppComponent {
  data:any;
  private url = 'http://localhost:8080/api/getwebpage';
  fileName= 'DataExport.xlsx';
  constructor(private http: HttpClient) { }
  ngOnInit() {
    this.getPageDetails();
  }
  getPageDetails() {
    console.log( this.http.get(this.url))
       this.http.get(this.url).subscribe(data => {
        this.data=data
        console.log( this.data);
        let element = document.getElementById('table');
        const ws: XLSX.WorkSheet =XLSX.utils.table_to_sheet(element);
   
        /* generate workbook and add the worksheet */
        const wb: XLSX.WorkBook = XLSX.utils.book_new();
        XLSX.utils.book_append_sheet(wb, ws, 'Blog');
     
        /* save to file */  
        XLSX.writeFile(wb, this.fileName);
        this.data.forEach((element:any) => {
          console.log(element)

          XLSX.writeFile(element, this.fileName);
          
        });
        return data;
      });
    
  }
  title = 'web-scraping';
}
